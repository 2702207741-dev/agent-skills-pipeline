# AI Agent Skills — 7-Skill Registry

AI agent skill 套件。`skills.json` 是唯一 registry，当前登记 7 个 skill，覆盖从创建、审查、安全、验证、编排、Git 到配置的工作流。

## Skill 概览

```
                ┌──────────────────────┐
                │  skill-authoring      │
                │  -workflow            │
                └──────────┬───────────┘
                           │
                           ▼
                ┌──────────────────────┐
                │  skill-review         │
                │  -workflow  ◄──  agent│
                │              +    -security-guard
                └──────────┬───────────┘
                           │
                           ▼
                ┌──────────────────────┐
                │  cross-model          │
                │  -verification        │
                └──────────┬───────────┘
                           │
                           ▼
                ┌──────────────────────┐
                │  skill-pipeline       │
                │  -orchestrator        │
                └──────────┬───────────┘
                           │
                           ▼
            ┌──────────────┴──────────────┐
            │  deploy to cloud / platform │
            └─────────────────────────────┘
```

| # | Skill | Type | 功能 |
|---|-------|------|------|
| 1 | **skill-authoring-workflow** | meta | 从需求到 SKILL.md 的完整创作流程（快速通道+完整 6 阶段） |
| 2 | **skill-review-workflow** | quality | 23 项审查（格式/内容/安全），三段严重级别 |
| 3 | **agent-security-guard** | security | API key 扫描、注入检测、shell 转义铁律 |
| 4 | **cross-model-verification** | testing | 跨模型对抗验证，含外发前敏感信息门禁 |
| 5 | **skill-pipeline-orchestrator** | workflow | 5 阶段管线一键编排（Author → Review+Sec → Verify → Package → Deploy） |
| 6 | **git-workflow-for-agents** | git | 6 步 git 操作流程（含 Expected Output 和失败修复） |
| 7 | **agent-config-reference** | reference | 多平台配置速查 + 排错决策树 |

## Registry

`skills.json` 是项目的唯一清单。新增、删除、重命名 skill 时，先更新 registry，再同步 README/CHANGELOG 并运行：

```bash
python scripts/check_registry.py
python scripts/validate-skill.py */SKILL.md
python scripts/run_fixture_checks.py
python scripts/security_scan.py
python scripts/run_rigorbench.py
python scripts/check_skill_graph.py
python scripts/create_release.py --dry-run
python scripts/marketplace.py list
python scripts/verify_release.py
```

## 安装

### 自动安装到已检测平台

```bash
# Preview detected platforms and target paths without writing.
bash scripts/install.sh --dry-run

# Install non-interactively; existing targets are backed up first.
bash scripts/install.sh --yes
```

## 验证

所有 registered skill 应通过 registry、格式、fixture、平台矩阵、安全、打包、release、marketplace 和安装 dry-run 检查。新机器 clone 后优先跑一条命令：

```bash
python scripts/verify_release.py
```

展开后的验证链路：

```bash
python scripts/check_registry.py
python scripts/validate-skill.py */SKILL.md
python scripts/run_fixture_checks.py
python scripts/security_scan.py
python scripts/run_rigorbench.py
python scripts/check_skill_graph.py
python scripts/package_skill.py --all ./dist
python scripts/create_release.py --output ./dist-release
python scripts/marketplace.py list
bash scripts/install.sh --dry-run
```

## Release & Marketplace

### Release Policy

当前发布版本由 `skills.json` 的 `version` 和 `release_policy.current_release` 定义。项目使用 semver：

- **Patch**：文档、fixture、测试或兼容性修复，不改变 skill 行为。
- **Minor**：新增 skill、平台支持、installer 能力或验证门禁，向后兼容。
- **Major**：重命名 skill、删除 skill、改变触发语义或破坏 installer/registry 兼容性。

发布冻结必须满足：

1. `skills.json` 与每个 `SKILL.md` frontmatter `version` 完全同步。
2. `python scripts/verify_release.py` 通过。
3. `scripts/create_release.py` 生成 artifact、manifest 和 `.sha256`。
4. `marketplace.py` 能从 release artifact 安装、更新、回滚。
5. 正式 skill 数量仍与 registry 一致，当前为 7 个。

发布资料在 `releases/v1.1.0/`，发布 artifact 由脚本生成：

```bash
python scripts/create_release.py --output ./releases/v1.1.0
```

该命令生成 `our-skills-v1.1.0.zip`、`our-skills-v1.1.0.manifest.json` 和 `our-skills-v1.1.0.sha256`。

Marketplace 风格安装器支持列出、安装、更新、回滚：

```bash
python scripts/marketplace.py list
python scripts/marketplace.py install --platform codex --target-root ~
python scripts/marketplace.py update --platform codex --target-root ~ --skill skill-review-workflow
python scripts/marketplace.py rollback --platform codex --target-root ~ --skill skill-review-workflow
```

## Industrial Roadmap

当前基线是生产级早期。工业级路线按证据链推进：

| Milestone | 目标 | 验收信号 |
|---|---|---|
| v1.2 | 冻结可信发布基线 | tag `v1.1.0`、artifact/checksum、one-command verification |
| v1.3 | 真实 E2E Harness | 每个 skill 至少 3 条真实 agent 运行轨迹 |
| v1.4 | 补齐通用 agent 空白域 | code-review/debugging/testing 等 roadmap domain 变正式 skill |
| v1.5 | 安全与供应链硬化 | 签名 artifact、SBOM、策略化安全扫描 |
| v2.0 | Skill Platform | marketplace index、doctor、质量 dashboard、弃用策略 |

## 目录结构

```
our-skills/
├── skills.json                                # 唯一 skill registry
├── benchmarks/                                # RigorBench 小基准与回归记录
├── fixtures/skill_e2e_cases.json              # 每个 skill 的端到端任务合约
├── graphs/skill_graph.json                    # skill 硬依赖/软协作图谱
├── marketplace/manifest.json                  # marketplace/installer 元数据
├── platforms/platform_test_matrix.json        # Hermes/Claude/Codex/Cursor 测试矩阵
├── releases/v1.1.0/                           # release manifest、migration、compatibility
├── roadmap/agent_skill_domains.json           # 尚未注册的通用 agent skill 空白域
├── agent-security-guard/SKILL.md              # Discipline-enforcing
├── cross-model-verification/SKILL.md          # Technique (Addyosmani)
├── skill-pipeline-orchestrator/SKILL.md       # Technique
├── skill-authoring-workflow/
│   ├── SKILL.md                               # meta-skill
│   └── references/
│       ├── full-workflow.md                   # 完整 6 阶段流程
│       ├── body-templates.md                  # 4 类型模板
│       ├── addyosmani-minimalist-style.md     # 极简风格指南
│       └── platform-adapters.md              # 多平台映射
├── skill-review-workflow/SKILL.md             # Discipline-enforcing
├── git-workflow-for-agents/SKILL.md           # Technique
├── agent-config-reference/SKILL.md            # Reference
└── scripts/
    ├── check_registry.py                      # registry 与目录一致性检查
    ├── check_skill_graph.py                   # 死链/孤岛/硬循环/阶段覆盖检查
    ├── create_release.py                      # 版本化 release artifact 生成
    ├── marketplace.py                         # list/install/update/rollback 安装器
    ├── run_rigorbench.py                      # 小型 RigorBench 与回归检查
    ├── run_fixture_checks.py                  # fixture/矩阵/空白域检查
    ├── security_scan.py                       # secret/shell/redaction 自动扫描
    ├── verify_release.py                      # 一条命令发布验证入口
    ├── validate-skill.py                      # 8 项格式验证
    ├── package_skill.py                       # 打包工具
    └── install.sh                             # 安装脚本
```

## 设计原则

- **description 铁律** — 只写触发条件，不写流程，防止 agent 跳过正文
- **Expected Output** — 每步必检，agent 有明确的"做对了"信号
- **Bad/Good 对照** — 反例+正例，不给 agent 猜的空间
- **Iron Law** — 条件→结果，无条件阻断（Discipline-enforcing 类型）
- **ASCII 决策树** — 分支可视化，路径清晰
