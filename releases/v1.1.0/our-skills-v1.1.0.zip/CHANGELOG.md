# Changelog

## Unreleased

### Added

- **skills.json** — single source of truth for the 7 registered skills.
- **scripts/check_registry.py** — verifies registry entries match skill directories and frontmatter names.
- **fixtures/skill_e2e_cases.json** — 1-3 end-to-end task contracts per registered skill.
- **roadmap/agent_skill_domains.json** — blank-domain backlog for planning, debugging, testing, code-review, requirements, observability, and incident-retro.
- **platforms/platform_test_matrix.json** — install and trigger verification matrix for Hermes, Claude Code, Codex, and Cursor.
- **scripts/run_fixture_checks.py** — validates fixture coverage, blank-domain coverage, and platform matrix completeness.
- **scripts/security_scan.py** — scans for likely secrets, dangerous shell patterns, and external-model redaction gate drift.
- **releases/v1.1.0/** — versioned release manifest, migration guide, and compatibility table.
- **scripts/create_release.py** — generates `our-skills-v<version>.zip` and checksum manifest from semver registry metadata.
- **scripts/verify_release.py** — one-command release verification for fresh clones and artifact install/rollback checks.
- **benchmarks/rigorbench.json** and **benchmarks/regression-history.json** — small RigorBench-style baseline with per-skill pass rates and regression records.
- **scripts/run_rigorbench.py** — evaluates fixture contracts and fails on pass-rate regressions.
- **marketplace/manifest.json** and **scripts/marketplace.py** — one-command list/install/update/rollback marketplace installer.
- **graphs/skill_graph.json** and **scripts/check_skill_graph.py** — dependency graph with dead-link, island, hard-cycle, and stage-coverage checks.
- CI workflow for registry validation, `validate-skill.py`, `git diff --check`, package smoke test, and installer dry-run.

### Changed

- README now reflects the 7-skill registry.
- README now documents release policy and the industrial-grade roadmap.
- `scripts/check_registry.py` now validates project and skill semver metadata.
- `scripts/install.sh` now reads `skills.json`, supports `--dry-run`, and backs up existing targets instead of silently deleting them.
- `scripts/package_skill.py` now matches the current `validate_skill()` return shape and can package every registered skill with `--all`.

## 1.0.0 (2026-07-06)

Initial release — 7-skill pipeline for AI agent workflows.

### Added

#### 新 Skill（3 个）
- **agent-security-guard** — 安全门禁（API key 扫描、注入检测、shell 转义）
- **cross-model-verification** — 跨模型对抗验证 + Adversarial Prompt 模板
- **skill-pipeline-orchestrator** — 5 阶段管线编排（Author → Review+Sec → Verify → Package → Deploy）

#### 升级 Skill（4 个）
- **skill-authoring-workflow** v1.5.0 — 新增快速通道、Iterative Refinement、Interaction 联动、4 个 reference 文件
- **skill-review-workflow** v1.1.0 — 新增 Security 严重级别、Expected Output 补全、Interaction 联动
- **git-workflow-for-agents** — 6 步全部补全 Expected Output，新增 API key 误提交检测
- **agent-config-reference** — Troubleshooting 重构为类型 A/B/C 决策树，新增 Security Configuration

#### 工具
- **scripts/validate-skill.py** — 8 项格式一键验证
- **scripts/package_skill.py** — 打包脚本
- **scripts/install.sh** — 多平台安装脚本

#### 文档
- README.md — 项目概览 + 安装指南
- skill-authoring-workflow/references/ 下 4 个参考文档

### Quality

- 7/7 registered skills 全部通过 validate-skill.py 8 项检查
- 5 阶段管线全流程测试通过
- 跨模型验证（Claude + GLM）发现并修复 5 个真实问题
- 双平台部署认证（Hermes Agent + Claude Code）
