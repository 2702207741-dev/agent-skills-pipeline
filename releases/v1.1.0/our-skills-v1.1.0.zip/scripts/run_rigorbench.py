#!/usr/bin/env python3
"""Run the small RigorBench-style evaluation for registered skills."""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "skills.json"
FIXTURES = ROOT / "fixtures" / "skill_e2e_cases.json"
BENCH = ROOT / "benchmarks" / "rigorbench.json"
HISTORY = ROOT / "benchmarks" / "regression-history.json"


def load_json(path: Path) -> Any:
    if not path.exists():
        raise AssertionError(f"missing required file: {path.relative_to(ROOT)}")
    return json.loads(path.read_text(encoding="utf-8"))


def contains_any(content: str, terms: list[Any]) -> bool:
    folded = content.casefold()
    return any(str(term).casefold() in folded for term in terms)


def score_case(case: dict[str, Any], skill_content: str) -> tuple[bool, list[str]]:
    failures: list[str] = []
    prompt = case.get("user_prompt", "")
    trigger = case.get("trigger", {})
    if trigger.get("expected") != "load":
        failures.append("trigger.expected is not load")
    if not contains_any(prompt, trigger.get("must_match_prompt_terms", [])):
        failures.append("prompt lacks trigger terms")
    if not contains_any(skill_content, trigger.get("must_exist_in_skill_terms", [])):
        failures.append("SKILL.md lacks trigger evidence")
    if not case.get("execution_contract"):
        failures.append("missing execution_contract")
    if not case.get("output_contract"):
        failures.append("missing output_contract")
    failure_branch = case.get("failure_branch", {})
    if not failure_branch.get("condition") or not failure_branch.get("expected_behavior"):
        failures.append("missing failure_branch")
    return not failures, failures


def run_benchmark() -> dict[str, Any]:
    registry = load_json(REGISTRY)
    fixtures = load_json(FIXTURES)
    bench = load_json(BENCH)
    history = load_json(HISTORY)

    if bench.get("source_fixture_file") != "fixtures/skill_e2e_cases.json":
        raise AssertionError("rigorbench source_fixture_file must point at fixtures/skill_e2e_cases.json")

    registered = {entry["name"]: entry for entry in registry["skills"]}
    by_skill: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for case in fixtures["cases"]:
        by_skill[case["skill"]].append(case)

    results: dict[str, Any] = {}
    for skill, entry in registered.items():
        skill_file = ROOT / entry["path"] / "SKILL.md"
        content = skill_file.read_text(encoding="utf-8")
        cases = by_skill.get(skill, [])
        if not cases:
            raise AssertionError(f"{skill} has no benchmark cases")
        passed = 0
        failures: list[dict[str, Any]] = []
        for case in cases:
            ok, case_failures = score_case(case, content)
            if ok:
                passed += 1
            else:
                failures.append({"case": case["id"], "failures": case_failures})
        total = len(cases)
        results[skill] = {
            "passed": passed,
            "total": total,
            "pass_rate": round(passed / total, 4),
            "failures": failures,
        }

    latest = history["history"][-1]["results"]
    regressions = []
    for skill, result in results.items():
        baseline = latest.get(skill)
        if baseline is None:
            regressions.append(f"{skill}: missing baseline")
            continue
        if result["pass_rate"] < baseline["pass_rate"]:
            regressions.append(f"{skill}: pass rate {result['pass_rate']} < baseline {baseline['pass_rate']}")

    return {
        "suite": bench["suite"],
        "release": registry["release_policy"]["current_release"],
        "results": results,
        "regressions": regressions,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="Print machine-readable result JSON")
    args = parser.parse_args()

    try:
        report = run_benchmark()
    except AssertionError as exc:
        print(f"[FAIL] {exc}")
        return 1

    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        for skill, result in report["results"].items():
            print(f"{skill}: {result['passed']}/{result['total']} pass_rate={result['pass_rate']:.2f}")
        if report["regressions"]:
            print("[FAIL] Regressions detected:")
            for regression in report["regressions"]:
                print(f"  - {regression}")
            return 1
        print("[OK] RigorBench passed with no regressions")
    return 0


if __name__ == "__main__":
    sys.exit(main())
