#!/usr/bin/env python3
"""Run the full one-command release verification gate."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable


def run(args: list[str], cwd: Path = ROOT) -> None:
    print("+ " + " ".join(args))
    subprocess.run(args, cwd=cwd, check=True)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def registry_skill_paths() -> list[str]:
    registry = json.loads((ROOT / "skills.json").read_text(encoding="utf-8"))
    return [entry["path"] for entry in registry["skills"]]


def assert_seven_skills_only() -> None:
    skill_files = sorted(path for path in ROOT.glob("*/SKILL.md"))
    if len(skill_files) != 7:
        raise AssertionError(f"expected 7 formal skills, found {len(skill_files)}")
    if (ROOT / "cg-extraction-workflow").exists():
        raise AssertionError("cg-extraction-workflow must not exist in the release baseline")


def verify_release_artifact(tmp: Path) -> Path:
    out = tmp / "dist-release"
    run([PYTHON, "scripts/create_release.py", "--output", str(out)])
    artifact = out / "our-skills-v1.1.0.zip"
    manifest = out / "our-skills-v1.1.0.manifest.json"
    checksum = out / "our-skills-v1.1.0.sha256"
    if not artifact.exists() or not manifest.exists() or not checksum.exists():
        raise AssertionError("release artifact, manifest, or checksum file is missing")

    manifest_data = json.loads(manifest.read_text(encoding="utf-8"))
    actual = sha256(artifact)
    if manifest_data["sha256"] != actual:
        raise AssertionError("release manifest sha256 does not match artifact")
    if not checksum.read_text(encoding="utf-8").startswith(actual):
        raise AssertionError("sha256 file does not match artifact")
    return artifact


def verify_artifact_install_and_rollback(artifact: Path, tmp: Path) -> None:
    extracted = tmp / "artifact-root"
    with zipfile.ZipFile(artifact) as zipf:
        zipf.extractall(extracted)

    market_home = tmp / "market-home"
    run([PYTHON, "scripts/marketplace.py", "install", "--platform", "codex", "--target-root", str(market_home)], cwd=extracted)
    installed = market_home / ".codex" / "skills" / "skill-review-workflow" / "SKILL.md"
    if not installed.exists():
        raise AssertionError("artifact install did not place skill-review-workflow")

    run([PYTHON, "scripts/marketplace.py", "update", "--platform", "codex", "--target-root", str(market_home), "--skill", "skill-review-workflow"], cwd=extracted)
    run([PYTHON, "scripts/marketplace.py", "rollback", "--platform", "codex", "--target-root", str(market_home), "--skill", "skill-review-workflow"], cwd=extracted)


def main() -> int:
    try:
        assert_seven_skills_only()
        run([PYTHON, "scripts/check_registry.py"])
        run([PYTHON, "scripts/validate-skill.py", *registry_skill_paths()])
        run([PYTHON, "scripts/run_fixture_checks.py"])
        run([PYTHON, "scripts/security_scan.py"])
        run([PYTHON, "scripts/run_rigorbench.py"])
        run([PYTHON, "scripts/check_skill_graph.py"])

        with tempfile.TemporaryDirectory(prefix="our-skills-release-verify-") as tmp_dir:
            tmp = Path(tmp_dir)
            package_out = tmp / "packages"
            run([PYTHON, "scripts/package_skill.py", "--all", str(package_out)])
            if len(list(package_out.glob("*.zip"))) != 7:
                raise AssertionError("package --all did not produce 7 zip files")

            artifact = verify_release_artifact(tmp)
            verify_artifact_install_and_rollback(artifact, tmp)

        run([PYTHON, "scripts/marketplace.py", "list"])
    except Exception as exc:
        print(f"[FAIL] {exc}")
        return 1

    print("[OK] Full release verification passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
