#!/usr/bin/env python3
"""Scan for likely secrets, dangerous shell patterns, and redaction gate drift."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TEXT_SUFFIXES = {".md", ".json", ".py", ".sh", ".yml", ".yaml", ".txt"}
SHELL_SUFFIXES = {".sh", ".bash", ".zsh", ".ps1", ".yml", ".yaml"}
EXCLUDED_DIRS = {".git", "__pycache__", ".pytest_cache", "dist", "temp", "tmp"}

SECRET_PATTERNS = [
    ("aws_access_key_id", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("google_api_key", re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b")),
    ("slack_token", re.compile(r"\bxox[baprs]-[0-9A-Za-z-]{20,}\b")),
    ("openai_or_stripe_key", re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}\b")),
    ("private_key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")),
    (
        "generic_secret_assignment",
        re.compile(r"\b(password|secret|api[_-]?key|token)\s*[:=]\s*['\"]?([A-Za-z0-9_./+=-]{16,})", re.IGNORECASE),
    ),
]

DANGEROUS_SHELL_PATTERNS = [
    ("recursive_root_delete", re.compile(r"\brm\s+-rf\s+(?:/|\*|\.|~|\$HOME|%USERPROFILE%)\b")),
    ("force_push", re.compile(r"\bgit\s+push\s+(?:-[^\s]*f[^\s]*|--force)(?!-with-lease)\b")),
    ("sudo_recursive_delete", re.compile(r"\bsudo\s+rm\s+-r[f]?\b")),
    ("drop_table", re.compile(r"\bdrop\s+table\b", re.IGNORECASE)),
    ("delete_without_where", re.compile(r"\bdelete\s+from\s+\w+\s*;", re.IGNORECASE)),
]

SAFE_EXAMPLE_MARKERS = (
    "...",
    "<SECRET",
    "<token>",
    "sk-xxx",
    "placeholder",
    "example",
    "regex",
    "pattern",
)

REDACTION_TERMS = ("redact", "redaction", "local-only", "safe-to-dispatch", "abort")


def iter_text_files() -> list[Path]:
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if any(part in EXCLUDED_DIRS for part in path.relative_to(ROOT).parts):
            continue
        if path.suffix.lower() in TEXT_SUFFIXES:
            files.append(path)
    return files


def read_lines(path: Path) -> list[str]:
    try:
        return path.read_text(encoding="utf-8").splitlines()
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8", errors="ignore").splitlines()


def is_safe_example(line: str) -> bool:
    folded = line.casefold()
    return any(marker.casefold() in folded for marker in SAFE_EXAMPLE_MARKERS)


def scan_secrets(files: list[Path]) -> list[str]:
    findings: list[str] = []
    for path in files:
        rel = path.relative_to(ROOT)
        for line_no, line in enumerate(read_lines(path), start=1):
            if is_safe_example(line):
                continue
            for name, pattern in SECRET_PATTERNS:
                if pattern.search(line):
                    findings.append(f"{rel}:{line_no}: {name}")
    return findings


def scan_dangerous_shell(files: list[Path]) -> list[str]:
    findings: list[str] = []
    for path in files:
        if path.suffix.lower() not in SHELL_SUFFIXES:
            continue
        rel = path.relative_to(ROOT)
        for line_no, line in enumerate(read_lines(path), start=1):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            for name, pattern in DANGEROUS_SHELL_PATTERNS:
                if pattern.search(stripped):
                    findings.append(f"{rel}:{line_no}: {name}")
    return findings


def check_redaction_gate() -> list[str]:
    findings: list[str] = []
    skill_file = ROOT / "cross-model-verification" / "SKILL.md"
    content = skill_file.read_text(encoding="utf-8").casefold()
    for term in ("redact", "local-only", "abort"):
        if term not in content:
            findings.append(f"cross-model-verification/SKILL.md missing redaction gate term: {term}")

    fixture_file = ROOT / "fixtures" / "skill_e2e_cases.json"
    if not fixture_file.exists():
        findings.append("fixtures/skill_e2e_cases.json missing; cannot verify external-model redaction cases")
        return findings

    data = json.loads(fixture_file.read_text(encoding="utf-8"))
    cases = [case for case in data.get("cases", []) if case.get("skill") == "cross-model-verification"]
    if not cases:
        findings.append("cross-model-verification fixtures missing")
        return findings

    for case in cases:
        blob = json.dumps(case, ensure_ascii=False).casefold()
        if not any(term in blob for term in REDACTION_TERMS):
            findings.append(f"cross-model fixture {case.get('id', '<missing id>')} lacks redaction/degraded-mode contract")
    return findings


def main() -> int:
    files = iter_text_files()
    findings: list[str] = []
    findings.extend(scan_secrets(files))
    findings.extend(scan_dangerous_shell(files))
    findings.extend(check_redaction_gate())

    if findings:
        print("[FAIL] Security scan found issues:")
        for finding in findings:
            print(f"  - {finding}")
        return 1

    print(f"[OK] Security scan passed across {len(files)} text files")
    return 0


if __name__ == "__main__":
    sys.exit(main())
