#!/usr/bin/env python3
"""Create a versioned release artifact and release manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from datetime import date
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "skills.json"
SEMVER_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:[-+][0-9A-Za-z.-]+)?$")
ZIP_TIMESTAMP = (2026, 7, 7, 0, 0, 0)


def load_registry() -> dict[str, Any]:
    registry = json.loads(REGISTRY.read_text(encoding="utf-8"))
    version = registry.get("version")
    if not isinstance(version, str) or not SEMVER_RE.match(version):
        raise ValueError("skills.json version must be semver")
    expected_release = f"v{version}"
    release_policy = registry.get("release_policy", {})
    if release_policy.get("current_release") != expected_release:
        raise ValueError("release_policy.current_release must match skills.json version")
    for entry in registry.get("skills", []):
        skill_version = entry.get("version")
        if not isinstance(skill_version, str) or not SEMVER_RE.match(skill_version):
            raise ValueError(f"{entry.get('name')} missing semver skill version")
    return registry


def should_include(path: Path) -> bool:
    excluded = {".git", "__pycache__", ".pytest_cache", "dist", "dist-smoke", "dist-release", "tmp", "temp"}
    parts = set(path.relative_to(ROOT).parts)
    if parts & excluded:
        return False
    if path.suffix in {".pyc", ".pyo", ".zip", ".sha256"}:
        return False
    if path.name.startswith("our-skills-v") and path.name.endswith(".manifest.json"):
        return False
    return True


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def create_artifact(output_dir: Path, registry: dict[str, Any]) -> tuple[Path, Path]:
    version = registry["version"]
    release = f"v{version}"
    release_dir = ROOT / "releases" / release
    for required in ("release.json", "migration-guide.md", "compatibility.md"):
        if not (release_dir / required).exists():
            raise ValueError(f"missing release doc: releases/{release}/{required}")

    output_dir.mkdir(parents=True, exist_ok=True)
    artifact = output_dir / f"our-skills-{release}.zip"
    manifest = output_dir / f"our-skills-{release}.manifest.json"
    checksum = output_dir / f"our-skills-{release}.sha256"

    with zipfile.ZipFile(artifact, "w", zipfile.ZIP_DEFLATED) as zipf:
        for path in sorted(ROOT.rglob("*")):
            if path.is_file() and should_include(path):
                arcname = path.relative_to(ROOT).as_posix()
                info = zipfile.ZipInfo(arcname, ZIP_TIMESTAMP)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                zipf.writestr(info, path.read_bytes())

    release_manifest = {
        "schema_version": 1,
        "release": release,
        "version": version,
        "created_at": date.today().isoformat(),
        "artifact": artifact.name,
        "sha256": sha256(artifact),
        "skills": [
            {
                "name": entry["name"],
                "version": entry["version"],
                "path": entry["path"],
                "category": entry["category"],
            }
            for entry in registry["skills"]
        ],
    }
    manifest.write_text(json.dumps(release_manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    checksum.write_text(f"{release_manifest['sha256']}  {artifact.name}\n", encoding="utf-8")
    return artifact, manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="dist-release", help="Directory for release artifact and manifest")
    parser.add_argument("--dry-run", action="store_true", help="Validate release metadata without writing artifacts")
    args = parser.parse_args()

    try:
        registry = load_registry()
        if args.dry_run:
            print(f"[OK] Release metadata valid for v{registry['version']}")
            return 0
        artifact, manifest = create_artifact(Path(args.output), registry)
    except Exception as exc:
        print(f"[FAIL] {exc}")
        return 1

    print(f"[OK] Created release artifact: {artifact}")
    print(f"[OK] Created release manifest: {manifest}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
