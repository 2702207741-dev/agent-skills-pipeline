#!/usr/bin/env python3
"""Marketplace-style installer for listing, installing, updating, and rolling back skills."""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "skills.json"
MARKETPLACE = ROOT / "marketplace" / "manifest.json"
PLATFORM_ALIASES = {
    "hermes": "hermes",
    "claude": "claude-code",
    "claude-code": "claude-code",
    "codex": "codex",
    "cursor": "cursor",
}


def load_json(path: Path) -> Any:
    if not path.exists():
        raise ValueError(f"missing file: {path.relative_to(ROOT)}")
    return json.loads(path.read_text(encoding="utf-8"))


def load_registry() -> dict[str, Any]:
    registry = load_json(REGISTRY)
    marketplace = load_json(MARKETPLACE)
    if marketplace.get("version") != registry.get("version"):
        raise ValueError("marketplace manifest version must match registry version")
    return registry


def select_skills(registry: dict[str, Any], skill_name: str | None) -> list[dict[str, Any]]:
    skills = registry["skills"]
    if skill_name is None:
        return skills
    selected = [entry for entry in skills if entry["name"] == skill_name]
    if not selected:
        raise ValueError(f"unknown skill: {skill_name}")
    return selected


def platform_id(value: str) -> str:
    if value not in PLATFORM_ALIASES:
        raise ValueError(f"unsupported platform: {value}")
    return PLATFORM_ALIASES[value]


def target_base(home: Path, platform: str) -> Path:
    if platform == "hermes":
        return home / ".hermes" / "skills"
    if platform == "claude-code":
        return home / ".claude" / "skills"
    if platform == "codex":
        return home / ".codex" / "skills"
    if platform == "cursor":
        return home / ".cursor" / "skills"
    raise ValueError(f"unsupported platform: {platform}")


def skill_destination(base: Path, platform: str, entry: dict[str, Any]) -> Path:
    if platform == "hermes":
        return base / entry.get("category", "meta") / entry["name"]
    return base / entry["name"]


def backup_root(home: Path, platform: str, skill: str) -> Path:
    return home / ".our-skills-backups" / platform / skill


def copy_skill(source: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, dest)


def backup_existing(home: Path, platform: str, dest: Path, skill: str) -> Path | None:
    if not dest.exists():
        return None
    stamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    backup = backup_root(home, platform, skill) / stamp
    backup.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(dest), str(backup))
    return backup


def latest_backup(home: Path, platform: str, skill: str) -> Path | None:
    root = backup_root(home, platform, skill)
    if not root.exists():
        return None
    backups = sorted(path for path in root.iterdir() if path.is_dir())
    return backups[-1] if backups else None


def command_list(registry: dict[str, Any]) -> int:
    print(f"{registry['project']} {registry['version']}")
    for entry in registry["skills"]:
        print(f"{entry['name']}\t{entry['version']}\t{entry['category']}\t{entry['summary']}")
    return 0


def command_install_or_update(args: argparse.Namespace, update: bool) -> int:
    registry = load_registry()
    platform = platform_id(args.platform)
    home = Path(args.target_root).expanduser().resolve()
    base = target_base(home, platform)
    skills = select_skills(registry, args.skill)
    action = "UPDATE" if update else "INSTALL"

    for entry in skills:
        source = ROOT / entry["path"]
        dest = skill_destination(base, platform, entry)
        if args.dry_run:
            print(f"[DRY-RUN] {action} {entry['name']} -> {dest}")
            continue
        if not (source / "SKILL.md").exists():
            raise ValueError(f"source missing SKILL.md: {source}")
        if dest.exists():
            backup = backup_existing(home, platform, dest, entry["name"])
            print(f"[BACKUP] {dest} -> {backup}")
        copy_skill(source, dest)
        print(f"[OK] {entry['name']} -> {dest}")
    return 0


def command_rollback(args: argparse.Namespace) -> int:
    if not args.skill:
        raise ValueError("rollback requires --skill")
    registry = load_registry()
    platform = platform_id(args.platform)
    home = Path(args.target_root).expanduser().resolve()
    base = target_base(home, platform)
    entry = select_skills(registry, args.skill)[0]
    dest = skill_destination(base, platform, entry)
    backup = latest_backup(home, platform, entry["name"])
    if backup is None:
        raise ValueError(f"no rollback backup found for {entry['name']} on {platform}")
    if args.dry_run:
        print(f"[DRY-RUN] ROLLBACK {backup} -> {dest}")
        return 0
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(backup, dest)
    print(f"[OK] rolled back {entry['name']} from {backup}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("list", help="List installable skills")

    for command in ("install", "update"):
        child = sub.add_parser(command, help=f"{command} one or all skills")
        child.add_argument("--platform", required=True, choices=sorted(PLATFORM_ALIASES))
        child.add_argument("--target-root", default=str(Path.home()), help="Home-like root containing .codex/.claude/.hermes/.cursor")
        child.add_argument("--skill", help="Install only one skill; defaults to all")
        child.add_argument("--dry-run", action="store_true")

    rollback = sub.add_parser("rollback", help="Restore the latest marketplace backup for a skill")
    rollback.add_argument("--platform", required=True, choices=sorted(PLATFORM_ALIASES))
    rollback.add_argument("--target-root", default=str(Path.home()), help="Home-like root containing backup data")
    rollback.add_argument("--skill", required=True)
    rollback.add_argument("--dry-run", action="store_true")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        if args.command == "list":
            return command_list(load_registry())
        if args.command == "install":
            return command_install_or_update(args, update=False)
        if args.command == "update":
            return command_install_or_update(args, update=True)
        if args.command == "rollback":
            return command_rollback(args)
    except Exception as exc:
        print(f"[FAIL] {exc}")
        return 1
    return 1


if __name__ == "__main__":
    sys.exit(main())
